## Roller Package

The package `"roller"` is for simulating "rolling" a device any given number of times. This device can be modified with n>=2 sides and different probabilities (as long as they add up to 1). This package will aid in the simulation as well as the visualization of the frequencies of the results.

After defining a `"device"` object, you can use the function `roll()` to
_roll_ a device a given number of `times`. The output will be an object of class 
`"roll"`, which will contain the vector of `rolls`.
